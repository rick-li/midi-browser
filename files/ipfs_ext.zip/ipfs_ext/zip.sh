cd ../ && zip -r ipfs_ext.zip ./ipfs_ext -x '*.git*'
