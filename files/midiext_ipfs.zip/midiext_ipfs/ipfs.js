(async function () {
    let pin = async () => {
        alert(`正尋找最新的ipfs Hash`);
        let resp = await fetch('http://127.0.0.1:5001/api/v0/name/resolve?arg=QmSeJ41iXwebzm3KPTixBc3zoetBD61df76BRjE4RuY4YB', {
            method: 'post'
        });
        let json = await resp.json();
        let ipfsPath = json.Path;
        alert(`正在pin${ipfsPath}`);
        resp = await fetch(`http://127.0.0.1:5001/api/v0/pin/add?arg=${ipfsPath}`, {
            method: 'post'
        });
        json = await resp.json();
        console.log(json)
        if (json.Code != 0) {
            alert(`成功`);
        } else {
            alert(`${json.Message}`);
        }
    }
    window.onload = function () {
        if(location.port != 5001){
            return;
        }
        setTimeout(() => {
            document.body.appendChild(htmlToElement(`
            <div style="position:absolute;top: 14px;right: 100px;width: 180px;height: 50px;z-index: 999;"><button id="__delay_btn" style="background:rgb(11, 58, 83);color:white;padding: 14px;">固定最新的多成IPFS</button></div>
            `));
            document.getElementById('__delay_btn').addEventListener('click', pin);
        }, 0);

    };

    /**
     * @param {String} HTML representing a single element
     * @return {Element}
     */
    function htmlToElement(html) {
        var template = document.createElement('template');
        html = html.trim(); // Never return a text node of whitespace as the result
        template.innerHTML = html;
        return template.content.firstChild;
    }




}());