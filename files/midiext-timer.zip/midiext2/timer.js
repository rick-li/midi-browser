(function() {
    /**
     * @param {String} HTML representing a single element
     * @return {Element}
     */
    function htmlToElement(html) {
        var template = document.createElement('template');
        html = html.trim(); // Never return a text node of whitespace as the result
        template.innerHTML = html;
        return template.content.firstChild;
    }

    setTimeout(() => {
        
        let btn = document.getElementById('music_btn');
        
        
        if(btn){
            document.body.appendChild(htmlToElement(`
            <div style="position:absolute;top: 14px;right: 10px;width: 150px;height: 50px;z-index: 999;">
            <span><input id="__delay_value" type="number" style="width:50px;" value="35">分鐘後<button id="__delay_btn">播放</button></span></div>
            `));
            document.getElementById('__delay_btn').addEventListener('click', () => {
                let delay = document.getElementById('__delay_value').value;
                alert(delay + ' 分鐘後播放');
                setTimeout(() => {
                    btn.click();
                }, delay * 60 * 1000);
            });
        }
        
    }, 1000);
})();